# LaMadre777 Pre‑Order (Next.js + Tailwind)

## Quick start
```bash
npm i
cp .env.local.example .env.local   # paste your webhook URL
npm run dev
```

- Edit `app/page.tsx` to update pricing/copy.
- API route at `app/api/preorders/route.ts` forwards payload to `PREORDER_WEBHOOK`.
- Drop images into `public/`:
  - `public/logo-lamadre777.png`
  - `public/images/lamadre-hero.png`
