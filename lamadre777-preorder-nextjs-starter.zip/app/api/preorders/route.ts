import { NextResponse } from "next/server";

export async function POST(request: Request) {
  try {
    const body = await request.json();
    const submittedAt = new Date().toISOString();
    const payload = { ...body, submittedAt, source: "nextjs-app-router" };

    // Prefer a server-only webhook, fall back to the public one if necessary.
    const hook = process.env.PREORDER_WEBHOOK || process.env.NEXT_PUBLIC_PREORDER_WEBHOOK;
    if (hook) {
      const r = await fetch(hook, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });
      if (!r.ok) {
        const text = await r.text();
        console.error("Webhook error:", text);
        return NextResponse.json({ ok: false, error: "Webhook failed" }, { status: 502 });
      }
    }
    return NextResponse.json({ ok: true });
  } catch (e: any) {
    console.error(e);
    return NextResponse.json({ ok: false, error: e?.message || "Unknown error" }, { status: 500 });
  }
}
