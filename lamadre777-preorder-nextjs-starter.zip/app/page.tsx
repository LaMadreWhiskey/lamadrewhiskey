"use client";

import React, { useState } from "react";
import { Check, ChevronRight, Shield, Mail, MapPin, ShoppingBag, Loader2 } from "lucide-react";
import "./globals.css";

// --- Helper components (simple shadcn-like stubs if library not auto-available) ---
const cn = (...classes: string[]) => classes.filter(Boolean).join(" ");
const Card = ({ className = "", children }: any) => (
  <div className={cn("rounded-2xl shadow-xl bg-zinc-950/70 ring-1 ring-zinc-800", className)}>{children}</div>
);
const CardContent = ({ className = "", children }: any) => (
  <div className={cn("p-6", className)}>{children}</div>
);
const Button = ({ className = "", children, ...props }: any) => (
  <button
    {...props}
    className={cn(
      "inline-flex items-center justify-center gap-2 rounded-2xl px-5 py-3 text-sm font-semibold transition",
      "bg-yellow-500 text-black hover:bg-yellow-400 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-yellow-500 focus:ring-offset-black",
      className
    )}
  >
    {children}
  </button>
);
const Input = ({ className = "", ...props }: any) => (
  <input
    {...props}
    className={cn(
      "w-full rounded-xl bg-zinc-900/60 border border-zinc-800 px-4 py-3 text-sm text-zinc-100 placeholder-zinc-500 focus:outline-none focus:ring-2 focus:ring-yellow-500",
      className
    )}
  />
);
const Select = ({ className = "", children, ...props }: any) => (
  <select
    {...props}
    className={cn(
      "w-full rounded-xl bg-zinc-900/60 border border-zinc-800 px-4 py-3 text-sm text-zinc-100 focus:outline-none focus:ring-2 focus:ring-yellow-500",
      className
    )}
  >
    {children}
  </select>
);
const Label = ({ className = "", children, ...props }: any) => (
  <label {...props} className={cn("block text-sm font-medium text-zinc-300", className)}>
    {children}
  </label>
);
const Checkbox = ({ className = "", ...props }: any) => (
  <input type="checkbox" {...props} className={cn("h-4 w-4 rounded border-zinc-700 bg-zinc-900 text-yellow-500", className)} />
);

// --- Pricing (editable in one place) ---
const PRICING = {
  limitedBlack: { name: "Limited Black Edition (13Y)", priceEUR: "€45", tag: "Ultra‑limited" },
  premiumGold: { name: "Premium Gold (6Y)", priceEUR: "€—", tag: "Aged elegance" },
  original: { name: "Original (Irish Blend)", priceEUR: "€—", tag: "Signature" },
};

const countries = [
  "Belgium", "Netherlands", "France", "Germany", "United Kingdom", "Nigeria", "Canada", "United States", "Ireland", "Other"
];

const quantities = Array.from({ length: 12 }, (_, i) => i + 1);

export default function Page() {
  const [loading, setLoading] = useState(false);
  const [success, setSuccess] = useState(false);

  async function handleSubmit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    setLoading(true);
    const form = e.currentTarget as HTMLFormElement;
    const data = Object.fromEntries(new FormData(form) as any);

    // derive numeric price when available
    const editionPrices: Record<string, number | null> = {
      limitedBlack: 45,
      premiumGold: null,
      original: null,
    };
    const editionPrice = editionPrices[String((data as any).edition)];

    try {
      const payload = {
        ...(data as any),
        quantity: Number((data as any).quantity),
        editionPrice,
        currency: "EUR",
        submittedAt: new Date().toISOString(),
        source: "lamadre777-preorder-web",
      };

      // Prefer server route; falls back to client webhook if present
      const resp = await fetch("/api/preorders", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });

      if (!resp.ok) {
        throw new Error("Submission failed");
      }

      setSuccess(true);
      form.reset();
      window.scrollTo({ top: 0, behavior: "smooth" });
    } catch (err) {
      alert("Something went wrong. Please try again or contact orders@lamadre777.com");
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="min-h-screen bg-black text-zinc-100">
      {/* Decorative gradient */}
      <div className="pointer-events-none fixed inset-0 -z-10">
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-yellow-500/5 via-black to-black" />
      </div>

      <header className="mx-auto flex max-w-6xl items-center justify-between px-6 py-6">
        <div className="flex items-center gap-3">
          <img src="/logo-lamadre777.png" alt="LaMadre777" className="h-10 w-10 rounded-xl object-contain ring-1 ring-zinc-800" />
          <div className="font-semibold tracking-wide">LaMadre777</div>
        </div>
        <nav className="hidden gap-6 md:flex">
          <a href="#preorder" className="text-sm text-zinc-300 hover:text-yellow-400">Pre‑order</a>
          <a href="#editions" className="text-sm text-zinc-300 hover:text-yellow-400">Editions</a>
          <a href="#about" className="text-sm text-zinc-300 hover:text-yellow-400">Story</a>
          <a href="#faq" className="text-sm text-zinc-300 hover:text-yellow-400">FAQ</a>
        </nav>
        <Button onClick={() => document.getElementById("preorder")?.scrollIntoView({behavior:"smooth"})}>
          <ShoppingBag className="h-4 w-4" /> Pre‑order now
        </Button>
      </header>

      <main>
        {/* Hero */}
        <section className="relative overflow-hidden">
          <div className="mx-auto grid max-w-6xl grid-cols-1 items-center gap-10 px-6 py-14 md:grid-cols-2 md:py-24">
            <div>
              {success ? (
                <div className="mb-6 rounded-2xl border border-green-600/40 bg-green-600/10 p-4 text-green-300">
                  <div className="flex items-center gap-2 font-semibold"><Check className="h-4 w-4"/> Thank you! Your pre‑order request has been received.</div>
                  <p className="mt-1 text-sm text-green-200/80">We’ll confirm availability and payment instructions by email within 48 hours.</p>
                </div>
              ) : null}
              <h1 className="text-4xl font-extrabold tracking-tight md:text-6xl">
                Black Luxury. Rare Craft. <span className="text-yellow-400">LaMadre777</span>
              </h1>
              <p className="mt-5 max-w-xl text-zinc-300">
                Born from Caribbean soul and African excellence, distilled in Belgium at Rubbens — one of the country’s oldest distilleries. Secure your bottle before public release.
              </p>
              <div className="mt-6 flex items-center gap-4">
                <div className="flex -space-x-2 overflow-hidden">
                  <span className="h-8 w-8 rounded-full bg-zinc-800 ring-2 ring-black" />
                  <span className="h-8 w-8 rounded-full bg-zinc-800 ring-2 ring-black" />
                  <span className="h-8 w-8 rounded-full bg-zinc-800 ring-2 ring-black" />
                </div>
                <p className="text-sm text-zinc-400">Trusted by our inner circle — limited first drop.</p>
              </div>
              <div className="mt-8 flex gap-3">
                <Button onClick={() => document.getElementById("preorder")?.scrollIntoView({behavior:"smooth"})}>
                  Pre‑order now <ChevronRight className="h-4 w-4"/>
                </Button>
                <a href="#editions" className="rounded-2xl px-5 py-3 text-sm font-semibold text-zinc-300 ring-1 ring-zinc-800 hover:text-yellow-400">Explore editions</a>
              </div>
              <div className="mt-6 flex items-center gap-2 text-xs text-zinc-400">
                <Shield className="h-4 w-4"/> Secure & age‑verified · EU GDPR compliant
              </div>
            </div>
            <div className="relative">
              <div className="absolute -inset-6 -z-10 rounded-[2rem] bg-gradient-to-br from-yellow-500/10 via-transparent to-transparent blur-2xl" />
              <Card className="bg-gradient-to-b from-zinc-950 to-black">
                <CardContent className="p-0">
                  <div className="aspect-[3/4] w-full rounded-2xl bg-[url('/images/lamadre-hero.png')] bg-cover bg-center"/>
                </CardContent>
              </Card>
            </div>
          </div>
        </section>

        {/* Editions */}
        <section id="editions" className="mx-auto max-w-6xl px-6 py-16 md:py-24">
          <h2 className="text-2xl font-bold md:text-3xl">The Editions</h2>
          <p className="mt-2 max-w-2xl text-sm text-zinc-400">Same iconic bottle. Three expressions for different moments.</p>

          <div className="mt-8 grid gap-6 md:grid-cols-3">
            {Object.entries(PRICING).map(([key, p]) => (
              <Card key={key}>
                <CardContent>
                  <div className="flex items-center justify-between">
                    <div>
                      <h3 className="text-lg font-semibold">{p.name}</h3>
                      <p className="text-xs text-zinc-400">{p.tag}</p>
                    </div>
                    <div className="text-right">
                      <div className="text-xl font-extrabold text-yellow-400">{(p as any).priceEUR}</div>
                      <div className="text-[11px] text-zinc-500">VAT incl. (TBA)</div>
                    </div>
                  </div>
                  <ul className="mt-4 space-y-2 text-sm text-zinc-300">
                    <li>• Caramel & star anise profile</li>
                    <li>• Distilled & bottled at Rubbens (BE)</li>
                    <li>• 70cl · 40% ABV</li>
                  </ul>
                </CardContent>
              </Card>
            ))}
          </div>
        </section>

        {/* Pre‑order form */}
        <section id="preorder" className="mx-auto max-w-6xl px-6 pb-20">
          <div className="grid items-start gap-8 md:grid-cols-2">
            <div>
              <h2 className="text-2xl font-bold md:text-3xl">Reserve your bottle(s)</h2>
              <p className="mt-2 max-w-prose text-sm text-zinc-400">
                This form registers your interest. We will email a confirmation with payment instructions if inventory is available in your region.
              </p>

              <form onSubmit={handleSubmit} className="mt-6 space-y-5">
                <div>
                  <Label htmlFor="edition">Edition</Label>
                  <Select name="edition" id="edition" required defaultValue="limitedBlack">
                    <option value="limitedBlack">{PRICING.limitedBlack.name}</option>
                    <option value="premiumGold">{PRICING.premiumGold.name}</option>
                    <option value="original">{PRICING.original.name}</option>
                  </Select>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="quantity">Quantity</Label>
                    <Select name="quantity" id="quantity" required defaultValue={1}>
                      {quantities.map(q => (
                        <option key={q} value={q}>{q}</option>
                      ))}
                    </Select>
                  </div>
                  <div>
                    <Label htmlFor="country">Country</Label>
                    <Select name="country" id="country" required defaultValue="Belgium">
                      {countries.map(c => (
                        <option key={c} value={c}>{c}</option>
                      ))}
                    </Select>
                  </div>
                </div>
                <div className="grid grid-cols-1 gap-4 md:grid-cols-2">
                  <div>
                    <Label htmlFor="firstName">First name</Label>
                    <Input id="firstName" name="firstName" required placeholder="Rayshida" />
                  </div>
                  <div>
                    <Label htmlFor="lastName">Last name</Label>
                    <Input id="lastName" name="lastName" required placeholder="Marcos" />
                  </div>
                </div>
                <div className="grid grid-cols-1 gap-4 md:grid-cols-2">
                  <div>
                    <Label htmlFor="email">Email</Label>
                    <div className="relative">
                      <Mail className="pointer-events-none absolute left-3 top-3 h-4 w-4 text-zinc-500" />
                      <Input id="email" name="email" type="email" required placeholder="you@domain.com" className="pl-9" />
                    </div>
                  </div>
                  <div>
                    <Label htmlFor="city">City</Label>
                    <div className="relative">
                      <MapPin className="pointer-events-none absolute left-3 top-3 h-4 w-4 text-zinc-500" />
                      <Input id="city" name="city" required placeholder="Antwerp" className="pl-9" />
                    </div>
                  </div>
                </div>
                <div>
                  <Label htmlFor="notes">Notes (optional)</Label>
                  <Input id="notes" name="notes" placeholder="Any delivery preferences, company billing, etc." />
                </div>
                <div className="flex items-start gap-3">
                  <Checkbox id="age" name="age" required />
                  <Label htmlFor="age" className="mt-[-2px] text-zinc-400">
                    I confirm I am of legal drinking age in my country.
                  </Label>
                </div>
                <div className="flex items-start gap-3">
                  <Checkbox id="gdpr" name="gdpr" required />
                  <Label htmlFor="gdpr" className="mt-[-2px] text-zinc-400">
                    I consent to the processing of my data for the purpose of managing this pre‑order. <a href="#privacy" className="underline decoration-yellow-500/40">Privacy Notice</a>
                  </Label>
                </div>

                <Button type="submit" disabled={loading} className="w-full md:w-auto">
                  {loading ? (<><Loader2 className="h-4 w-4 animate-spin"/> Submitting…</>) : (<><ShoppingBag className="h-4 w-4"/> Submit pre‑order</>)}
                </Button>
              </form>

              <p className="mt-4 text-xs text-zinc-500">
                Need help? Email <a className="underline decoration-yellow-500/40" href="mailto:orders@lamadre777.com">orders@lamadre777.com</a>
              </p>
            </div>

            <div>
              <Card className="bg-zinc-950/70">
                <CardContent>
                  <h3 className="text-lg font-semibold">How pre‑orders work</h3>
                  <ul className="mt-3 space-y-3 text-sm text-zinc-300">
                    <li>1. Submit the form — no payment yet.</li>
                    <li>2. We confirm stock & shipping options in your country.</li>
                    <li>3. You receive a secure payment link (Stripe/Bank) to finalize.</li>
                    <li>4. Orders ship once production lot clears quality control at Rubbens.</li>
                  </ul>
                  <div className="mt-6 rounded-xl border border-zinc-800 p-4 text-xs text-zinc-400">
                    <p><strong>Note:</strong> For Nigeria & Canada, distribution timelines may vary due to local regulations.</p>
                  </div>
                </CardContent>
              </Card>

              <div className="mt-6 grid gap-6 md:grid-cols-2">
                <Card>
                  <CardContent>
                    <div className="text-sm text-zinc-400">Estimated dispatch</div>
                    <div className="text-xl font-bold text-yellow-400">Q4 2025</div>
                  </CardContent>
                </Card>
                <Card>
                  <CardContent>
                    <div className="text-sm text-zinc-400">ABV</div>
                    <div className="text-xl font-bold text-yellow-400">40%</div>
                  </CardContent>
                </Card>
              </div>

              <Card className="mt-6">
                <CardContent>
                  <h3 id="about" className="text-lg font-semibold">The LaMadre777 Story</h3>
                  <p className="mt-2 text-sm text-zinc-300">
                    A celebration of black luxury and motherhood — biological or chosen. Crafted with caramel and star anise notes, and bottled in our signature black‑and‑gold aesthetic.
                  </p>
                </CardContent>
              </Card>
            </div>
          </div>
        </section>

        {/* FAQ */}
        <section id="faq" className="mx-auto max-w-6xl px-6 pb-24">
          <h2 className="text-2xl font-bold md:text-3xl">FAQ</h2>
          <div className="mt-6 grid gap-4 md:grid-cols-2">
            {[
              ["When will I be charged?", "Only after we confirm inventory. You’ll receive a secure payment link."],
              ["Where do you ship?", "EU, UK, Nigeria, and Canada to start. Some regions may be pickup only until local compliance is finalized."],
              ["Is this limited?", "Yes — first production is small. Priority goes to our Inner Circle list."],
              ["Can I edit my order?", "Reply to the confirmation email to adjust details before payment."],
            ].map(([q,a]) => (
              <Card key={q}><CardContent>
                <div className="font-semibold">{q}</div>
                <div className="mt-1 text-sm text-zinc-300">{a}</div>
              </CardContent></Card>
            ))}
          </div>
        </section>
      </main>

      <footer className="border-t border-zinc-900/60 bg-black/40">
        <div className="mx-auto grid max-w-6xl grid-cols-1 gap-6 px-6 py-10 md:grid-cols-3">
          <div>
            <div className="text-lg font-semibold">LaMadre777</div>
            <p className="mt-2 text-sm text-zinc-400">Distilled & bottled at Rubbens Distillery, Belgium.</p>
          </div>
          <div className="text-sm text-zinc-400">
            <a href="#privacy" className="hover:text-yellow-400">Privacy</a> · <a href="#terms" className="hover:text-yellow-400">Terms</a> · <a href="#cookies" className="hover:text-yellow-400">Cookies</a>
          </div>
          <div className="text-sm text-zinc-400">© {new Date().getFullYear()} LaMadre777. All rights reserved.</div>
        </div>
      </footer>
    </div>
  );
}
