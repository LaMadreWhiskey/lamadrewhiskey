export const metadata = {
  title: "LaMadre777 – Pre‑Order",
  description: "Black luxury. Rare craft. Pre‑order LaMadre777.",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
